
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes
import asyncio

TOKEN = '8051659842:AAF5b3H74YI02oe7NKFmAeuZwJnZupnDOoo'
GRUPO_ID = -1001719696696
PAGAMENTO_LINK = 'https://mpago.la/22w162C'

usuarios = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    usuarios[user_id] = {"etapa": "descricao"}
    await update.message.reply_text("Olá! Envie a **descrição** do seu anúncio.", parse_mode='Markdown')

async def mensagem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in usuarios:
        await update.message.reply_text("Use /start para começar.")
        return

    dados = usuarios[user_id]
    texto = update.message.text or ""
    if dados["etapa"] == "descricao":
        dados["descricao"] = texto
        dados["etapa"] = "imagem"
        await update.message.reply_text("Agora envie a **imagem** do seu anúncio.")
    elif dados["etapa"] == "link":
        dados["link"] = texto
        dados["etapa"] = "finalizar"
        await solicitar_pagamento(update, context)
    else:
        await update.message.reply_text("Envie o conteúdo conforme solicitado.")

async def imagem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in usuarios:
        return

    dados = usuarios[user_id]
    if dados["etapa"] != "imagem":
        return

    if update.message.photo:
        dados["foto"] = update.message.photo[-1].file_id
        dados["etapa"] = "link"
        await update.message.reply_text("Agora envie o **link do botão** do seu anúncio.", parse_mode='Markdown')

async def solicitar_pagamento(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    botao = InlineKeyboardMarkup([[InlineKeyboardButton("Pagar R$3", url=PAGAMENTO_LINK)]])
    await update.message.reply_text("Para finalizar e agendar seu anúncio, clique no botão abaixo para pagar:", reply_markup=botao)
    await asyncio.sleep(10)
    await confirmar_pagamento(update, context)

async def confirmar_pagamento(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in usuarios:
        dados = usuarios[user_id]
        await context.bot.send_photo(
            chat_id=GRUPO_ID,
            photo=dados["foto"],
            caption=dados["descricao"],
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Acessar produto", url=dados["link"])]]) if dados.get("link") else None
        )
        await update.message.reply_text("Anúncio postado com sucesso!")
        usuarios.pop(user_id, None)

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.PHOTO, imagem))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, mensagem))

app.run_polling()
