
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes
import asyncio

TOKEN = '8051659842:AAF5b3H74YI02oe7NKFmAeuZwJnZupnDOoo'
GROUP_ID = -1001719696696

user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Olá! Envie a imagem do seu anúncio.")

async def image_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if update.message.photo:
        user_data[user_id] = {'image': update.message.photo[-1].file_id}
        await update.message.reply_text("Agora envie a descrição do anúncio.")

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id in user_data and 'image' in user_data[user_id] and 'description' not in user_data[user_id]:
        user_data[user_id]['description'] = update.message.text
        await update.message.reply_text("Agora envie o link do botão.")
    elif user_id in user_data and 'description' in user_data[user_id] and 'link' not in user_data[user_id]:
        user_data[user_id]['link'] = update.message.text
        await update.message.reply_text("Pronto! Agora pague R$3 no Pix lojadias10@gmail.com e envie 'PAGO' aqui.")

async def pagamento_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if update.message.text.strip().upper() == "PAGO":
        anuncio = user_data.get(user_id)
        if anuncio:
            button = InlineKeyboardButton("Acessar Produto", url=anuncio['link'])
            markup = InlineKeyboardMarkup([[button]])
            await context.bot.send_photo(chat_id=GROUP_ID, photo=anuncio['image'],
                                         caption=anuncio['description'], reply_markup=markup)
            await update.message.reply_text("Anúncio postado com sucesso!")
        else:
            await update.message.reply_text("Dados incompletos. Recomece com /start.")

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.PHOTO, image_handler))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), text_handler))
    app.add_handler(MessageHandler(filters.TEXT & filters.Regex("(?i)pago"), pagamento_handler))
    app.run_polling()

if __name__ == '__main__':
    import nest_asyncio
    nest_asyncio.apply()
    main()
    