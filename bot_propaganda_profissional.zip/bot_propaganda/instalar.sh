
#!/data/data/com.termux/files/usr/bin/bash

pkg update -y
pkg install -y python git unzip
pip install --upgrade pip
pip install python-telegram-bot==20.3 nest_asyncio
python bot.py
