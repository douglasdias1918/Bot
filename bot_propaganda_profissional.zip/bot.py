
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
import asyncio

TOKEN = '8051659842:AAF5b3H74YI02oe7NKFmAeuZwJnZupnDOoo'
GROUP_ID = -1001719696696

logging.basicConfig(level=logging.INFO)
user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_data[user_id] = {"step": "desc"}
    await update.message.reply_text("Olá! Envie a **descrição** da propaganda.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in user_data:
        await update.message.reply_text("Use /start para iniciar.")
        return

    step = user_data[user_id]["step"]
    text = update.message.text

    if step == "desc":
        user_data[user_id]["desc"] = text
        user_data[user_id]["step"] = "imagem"
        await update.message.reply_text("Agora envie a **imagem** da propaganda.")
    elif step == "imagem" and update.message.photo:
        user_data[user_id]["image"] = update.message.photo[-1].file_id
        user_data[user_id]["step"] = "link"
        await update.message.reply_text("Envie o **link do botão**.")
    elif step == "link":
        user_data[user_id]["link"] = text
        user_data[user_id]["step"] = "confirmar"
        await update.message.reply_text(
            "Para finalizar e publicar por 4 dias, faça o pagamento de R$3 via Pix.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("Pagar com Pix", url="https://mpago.la/2xqDFUj")]]
            )
        )
        # Em produção, gere QR code com API do Mercado Pago e valide aqui
        # Após pagamento, envie para o grupo

async def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT | filters.PHOTO, handle_message))
    await app.run_polling()

if __name__ == "__main__":
    import nest_asyncio
    nest_asyncio.apply()
    asyncio.run(main())
