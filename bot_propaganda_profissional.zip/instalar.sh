
pkg update -y && pkg upgrade -y
pkg install -y python git unzip wget
pip install --upgrade pip
pip install python-telegram-bot==20.3 nest_asyncio
python bot.py
